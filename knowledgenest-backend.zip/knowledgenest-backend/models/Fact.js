const mongoose = require('mongoose');

const factSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: [{ type: String }], // Array of paragraphs
  image: { type: String, required: true },
  topic: { type: mongoose.Schema.Types.ObjectId, ref: 'Topic', required: true },
  slug: { type: String, required: true, unique: true },
  category: { type: String, default: 'all' } // For filters
}, { timestamps: true });

module.exports = mongoose.model('Fact', factSchema);